<?php $__env->startSection('content'); ?>
<section id="inquiries" class="py-5">
    <div class="container">
        <h2 class="text-center mb-4"><?php echo e($title); ?></h2>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Message</th>
                        <th>Status</th>
                        <th>Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(htmlspecialchars($inquiry->name, ENT_QUOTES, 'UTF-8')); ?></td>
                            <td><?php echo e(htmlspecialchars($inquiry->email, ENT_QUOTES, 'UTF-8')); ?></td>
                            <td><?php echo e(htmlspecialchars($inquiry->phone, ENT_QUOTES, 'UTF-8')); ?></td>
                            <td><?php echo e(htmlspecialchars($inquiry->message, ENT_QUOTES, 'UTF-8')); ?></td>
                            <td>
                            <form action="<?php echo e(route('admin.inquiries.updateStatus', $inquiry->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <select name="status" class="form-select" onchange="this.form.submit()">
                                        <option value="Pending" <?php echo e($inquiry->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                        <option value="Followed Up" <?php echo e($inquiry->status == 'Followed Up' ? 'selected' : ''); ?>>Followed Up</option>
                                        <option value="Converted" <?php echo e($inquiry->status == 'Converted' ? 'selected' : ''); ?>>Converted</option>
                                        <option value="Declined" <?php echo e($inquiry->status == 'Declined' ? 'selected' : ''); ?>>Declined</option>
                                    </select>
                                </form>
                            </td>
                            <td>
                            <form action="<?php echo e(route('admin.inquiries.updateNotes', $inquiry->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <textarea name="notes" class="form-control" rows="2"><?php echo e($inquiry->notes); ?></textarea>
                                    <button type="submit" class="btn btn-primary mt-2">Update Notes</button>
                                </form>
                            </td>
                            <td>
                                <form action="<?php echo e(route('admin.inquiries.destroy', $inquiry->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this inquiry?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TechVista\techvista\techvista\resources\views/inquiries/index.blade.php ENDPATH**/ ?>