<?php $__env->startSection('content'); ?>
	<div class="d-flex justify-content-center">
		<h1><?php echo e($title); ?></h1>
	</div>
	<div class="d-flex justify-content-center">
		<div class="card col-8">

			<div class="card-body">
				<form action="<?php echo e(route('InquiryStore')); ?>" method="POST" class="form" enctype="multipart/form-data" novalidate>
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<p><label for="name">Name</label><br />
							<input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>"><br />
							<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
					</div>

					<div class="form-group">
						<p><label for="started_on">Started On</label><br />
							<input type="date" name="started_on" class="form-control" value="<?php echo e(old('started_on')); ?>"><br />
							<?php $__errorArgs = ['started_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
					</div>

					<div class="form-group">
						<p><label for="cost">Cost</label><br />
							<input type="text" name="cost" class="form-control" value="<?php echo e(old('cost')); ?>"><br />
							<?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
					</div>

					<div class="form-group">
						<p><label for="speed">Speed</label><br />
							<input type="text" name="speed" class="form-control" value="<?php echo e(old('speed')); ?>"><br />
							<?php $__errorArgs = ['speed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
					</div>

					<div class="form-group">
						<p><label for="short_description">Short Description</label><br />
							<textarea rows="5" name="short_description" id="short_description" class="form-control"><?php echo e(old('short_description')); ?></textarea><br />
							<?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</p>
					</div>

					<div class="form-group">
						<p><label for="description">Description</label><br />
							<textarea rows="10" name="description" id="description" class="form-control"><?php echo e(old('description')); ?></textarea><br />
							<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</p>
					</div>

					<div class="form-group">
						<p><label for="image">Image</label><br />
							<input type="file" name="image" id="image"></p>
						<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
					</div>

					<div class="form-group">
						<p><button class="btn btn-primary" type="submit">Submit</button></p>
					</div>
				</form>
			</div>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TechVista\techvista\techvista\resources\views/admin/create.blade.php ENDPATH**/ ?>