<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>

	<section class="pt-4">
		<div class="container px-4">
			<div class="row gx-4 justify-content-center">
				<div class="col-lg-8">
			<h2>Welcome to TechVista Innovations Ltd.</h2>
			<p>
				At TechVista Innovations Ltd., we are dedicated to providing top-notch software development services that cater to your unique business needs. Our mission is to empower businesses with innovative software solutions, guided by our core values of integrity, excellence, and collaboration. We specialize in creating customized software solutions that drive efficiency, productivity, and growth.
			</p>
		</div>
	</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TechVista\techvista\techvista\resources\views/home.blade.php ENDPATH**/ ?>