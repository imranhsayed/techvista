@props(['field'])

@error($field)<span class="text text-danger">{{ $message }}</span>@enderror
